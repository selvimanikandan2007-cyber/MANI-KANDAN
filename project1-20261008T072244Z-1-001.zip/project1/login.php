<?php
// login.php - User login page
session_start();

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

require_once 'db.php';

// Initialize variables
$email = $password = "";
$errors = [];

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input
    $email = sanitizeInput($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);

    // Validation
    if (empty($email)) {
        $errors['email'] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Please enter a valid email address";
    }

    if (empty($password)) {
        $errors['password'] = "Password is required";
    }

    // If no errors, proceed with authentication
    if (empty($errors)) {
        $user = verifyUserCredentials($email, $password);

        if ($user) {
            // Set session variables
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['user_type'] = $user['user_type'];
            $_SESSION['first_name'] = $user['first_name'];

            // Set remember me cookie (optional)
            if ($remember) {
                $token = bin2hex(random_bytes(32));
                setcookie('remember_token', $token, time() + 86400 * 30, '/'); // 30 days
                // Store token in database (you'll need to implement this)
            }

            // Redirect to dashboard
            header("Location: dashboard.php");
            exit();
        } else {
            $errors['login'] = "Invalid email or password";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - EduGenie</title>
    <link rel="stylesheet" href="auth.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        .error-message {
            color: #ff3860;
            font-size: 12px;
            margin-top: 5px;
            display: none;
        }
        .error-message.show {
            display: block;
        }
        .input-error {
            border-color: #ff3860 !important;
        }
    </style>
</head>
<body class="auth-page">
    <!-- Background Animation -->
    <div class="auth-bg"></div>
    <div class="floating-shapes">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
        <div class="shape shape-3"></div>
        <div class="shape shape-4"></div>
    </div>

    <div class="auth-container">
        <!-- Left Panel -->
        <div class="auth-left-panel">
            <div class="auth-brand">
                <div class="logo">
                    <i class="fas fa-brain"></i>
                    <h1>Edu<span>Genie</span></h1>
                </div>
                <p class="tagline">AI-Powered Learning Assistant</p>
            </div>

            <div class="benefits-list">
                <h3>Welcome Back!</h3>
                <ul>
                    <li>
                        <i class="fas fa-check-circle"></i>
                        <span>Access your personalized dashboard</span>
                    </li>
                    <li>
                        <i class="fas fa-check-circle"></i>
                        <span>Continue your learning journey</span>
                    </li>
                    <li>
                        <i class="fas fa-check-circle"></i>
                        <span>View your document analysis history</span>
                    </li>
                    <li>
                        <i class="fas fa-check-circle"></i>
                        <span>Check your progress & analytics</span>
                    </li>
                    <li>
                        <i class="fas fa-check-circle"></i>
                        <span>Get AI-powered recommendations</span>
                    </li>
                </ul>
            </div>

            <div class="stats-grid">
                <div class="stat">
                    <div class="stat-number">10,000+</div>
                    <div class="stat-label">Active Learners</div>
                </div>
                <div class="stat">
                    <div class="stat-number">24/7</div>
                    <div class="stat-label">AI Support</div>
                </div>
                <div class="stat">
                    <div class="stat-number">99.9%</div>
                    <div class="stat-label">Uptime</div>
                </div>
            </div>
        </div>

        <!-- Right Panel - Login Form -->
        <div class="auth-right-panel">
            <div class="auth-header">
                <h2>Welcome Back</h2>
                <p>Sign in to continue your learning journey</p>

                <div class="auth-tabs">
                    <a href="login.php" class="auth-tab active">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </a>
                    <a href="signup.php" class="auth-tab">
                        <i class="fas fa-user-plus"></i> Sign Up
                    </a>
                </div>
            </div>

            <?php if (isset($errors['login'])): ?>
                <div class="error-message" style="display: block; background: #ff3860; color: white; padding: 10px; border-radius: 5px; margin-bottom: 15px;">
                    <?php echo htmlspecialchars($errors['login']); ?>
                </div>
            <?php endif; ?>

            <form id="loginForm" class="auth-form" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="email">
                        <i class="fas fa-envelope"></i> Email Address
                    </label>
                    <input type="email" id="email" name="email" placeholder="student@example.com" value="<?php echo htmlspecialchars($email); ?>" required 
                        class="<?php echo isset($errors['email']) ? 'input-error' : ''; ?>">
                    <div class="error-message" id="emailError">
                        <?php echo isset($errors['email']) ? htmlspecialchars($errors['email']) : ''; ?>
                    </div>
                </div>

                <div class="form-group">
                    <div class="label-row">
                        <label for="password">
                            <i class="fas fa-lock"></i> Password
                        </label>
                        <a href="forgot-password.php" class="forgot-link">Forgot Password?</a>
                    </div>
                    <div class="password-input">
                        <input type="password" id="password" name="password" placeholder="Enter your password" required 
                            class="<?php echo isset($errors['password']) ? 'input-error' : ''; ?>">
                        <button type="button" class="toggle-password" id="togglePassword">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <div class="error-message" id="passwordError">
                        <?php echo isset($errors['password']) ? htmlspecialchars($errors['password']) : ''; ?>
                    </div>
                </div>

                <div class="form-options">
                    <label class="checkbox">
                        <input type="checkbox" id="remember" name="remember" <?php echo isset($_POST['remember']) ? 'checked' : ''; ?>>
                        <span class="checkmark"></span>
                        Remember me
                    </label>
                </div>

                <button type="submit" class="auth-submit-btn" id="loginSubmit">
                    <span class="btn-text">Sign In</span>
                    <div class="btn-loader">
                        <div class="spinner"></div>
                    </div>
                    <i class="fas fa-sign-in-alt btn-icon"></i>
                </button>

                <div class="divider">
                    <span>Or continue with</span>
                </div>

                <div class="social-login">
                    <button type="button" class="social-btn google">
                        <i class="fab fa-google"></i>
                        <span>Google</span>
                    </button>
                    <button type="button" class="social-btn github">
                        <i class="fab fa-github"></i>
                        <span>GitHub</span>
                    </button>
                    <button type="button" class="social-btn microsoft">
                        <i class="fab fa-microsoft"></i>
                        <span>Microsoft</span>
                    </button>
                </div>

                <div class="auth-footer">
                    <p>Don't have an account? <a href="signup.php">Create one here</a></p>
                </div>
            </form>
        </div>

        <!-- Back to Home -->
        <a href="index.php" class="back-home">
            <i class="fas fa-arrow-left"></i> Back to Home
        </a>
    </div>

    <script>
        // Toggle password visibility
        document.getElementById('togglePassword').addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            const icon = this.querySelector('i');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });

        // Form submission
        document.getElementById('loginForm')?.addEventListener('submit', function(e) {
            const submitBtn = document.getElementById('loginSubmit');
            const btnText = submitBtn.querySelector('.btn-text');
            const btnLoader = submitBtn.querySelector('.btn-loader');
            
            // Show loading state
            submitBtn.disabled = true;
            btnText.textContent = 'Signing In...';
            btnLoader.style.display = 'block';
        });

        // Show error messages on page load
        document.addEventListener('DOMContentLoaded', function() {
            const errorElements = document.querySelectorAll('.error-message');
            errorElements.forEach(element => {
                if (element.textContent.trim() !== '') {
                    element.style.display = 'block';
                    const input = element.parentElement.querySelector('input');
                    if (input) {
                        input.classList.add('input-error');
                    }
                }
            });
        });

        // Social login buttons
        document.querySelectorAll('.social-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const provider = this.querySelector('span').textContent.toLowerCase();
                alert(`Social login with ${provider} would be implemented here.`);
                // In a real application, you would redirect to OAuth endpoint
                // window.location.href = `auth/${provider}.php`;
            });
        });
    </script>

</body>
</html>
<link rel="stylesheet" href="singupandlogingcss.css">

<body>
    </body>