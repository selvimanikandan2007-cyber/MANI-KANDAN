// ... inside index.js

// Form Submission Logic
const uploadForm = document.getElementById('uploadForm');
// ... other variable declarations ...

if (uploadForm && submitBtn) {
    uploadForm.addEventListener('submit', async function (e) {
        e.preventDefault(); // Stop the page from reloading

        const textArea = this.querySelector('#topic_text');
        const fileInput = this.querySelector('#question_paper');

        // 1. Validation
        if (!textArea.value.trim() && (!fileInput.files || fileInput.files.length === 0)) {
            showFlashMessage('Please enter text or upload a file.', 'warning');
            return;
        }

        // 2. Show Loading State
        if (loadingSpinner && arrowIcon) {
            loadingSpinner.style.display = 'block';
            arrowIcon.style.display = 'none';
            submitBtn.disabled = true;
        }
        if (loadingOverlay) loadingOverlay.style.display = 'flex';

        try {
            // 3. Prepare Data
            // Note: For this example, we are sending the Text Area content.
            // (File parsing usually requires a PDF parser on the backend)
            const payload = {
                text: textArea.value
            };

            // 4. Send to analyze.php
            const response = await fetch('analyze.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            });

            const result = await response.json();

            // 5. Hide Loading
            if (loadingOverlay) loadingOverlay.style.display = 'none';
            loadingSpinner.style.display = 'none';
            arrowIcon.style.display = 'block';
            submitBtn.disabled = false;

            if (result.error) {
                showFlashMessage(result.error, 'error');
            } else {
                // SUCCESS! Display the results
                console.log("AI Insights:", result);
                displayResults(result);
                showFlashMessage('Analysis Complete!', 'success');
            }

        } catch (error) {
            console.error(error);
            if (loadingOverlay) loadingOverlay.style.display = 'none';
            submitBtn.disabled = false;
            showFlashMessage('An error occurred during analysis.', 'error');
        }
    });
}

// Helper function to display results dynamically
function displayResults(data) {
    // Scroll to results section
    const resultsSection = document.getElementById('what-youll-get');
    resultsSection.scrollIntoView({ behavior: 'smooth' });

    // Example: Injecting data into your "What You'll Get" cards
    // You can customize this to create a new modal or results div

    // We will create a simple overlay to show results for now
    const resultHTML = `
        <div class="results-container" style="padding: 20px; background: var(--bg-card); margin-top: 20px; border-radius: 15px; border: 1px solid var(--accent-primary);">
            <h3 style="color: var(--accent-primary); margin-bottom: 15px;">AI Insights</h3>
            
            <h4 style="color:white;">Summary</h4>
            <p style="color: var(--text-secondary); margin-bottom: 20px;">${data.summary}</p>
            
            <h4 style="color:white;">Key Topics</h4>
            <ul style="color: var(--text-secondary); margin-bottom: 20px; padding-left: 20px;">
                ${data.key_topics.map(topic => `<li>${topic}</li>`).join('')}
            </ul>

            <h4 style="color:white;">Practice Questions</h4>
            <ul style="color: var(--text-secondary); padding-left: 20px;">
                ${data.questions.map(q => `<li>${q}</li>`).join('')}
            </ul>
        </div>
    `;

    // Append this HTML to your features panel or a specific results div
    const container = document.querySelector('.features-panel');
    const existingResults = container.querySelector('.results-container');
    if (existingResults) existingResults.remove(); // Clear old results

    container.insertAdjacentHTML('afterbegin', resultHTML);
}