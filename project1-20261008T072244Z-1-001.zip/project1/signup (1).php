<?php
// signup.php - User registration page
session_start();

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

require_once 'db.php';

// Initialize variables
$firstName = $lastName = $username = $email = $password = $confirmPassword = $userType = "";
$errors = [];
$success = false;

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input
    $firstName = sanitizeInput($_POST['firstName'] ?? '');
    $lastName = sanitizeInput($_POST['lastName'] ?? '');
    $username = sanitizeInput($_POST['username'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';
    $userType = $_POST['userType'] ?? '';
    $newsletter = isset($_POST['newsletter']) ? 1 : 0;
    $terms = isset($_POST['terms']);

    // Validation
    if (empty($firstName)) {
        $errors['firstName'] = "First name is required";
    } elseif (strlen($firstName) < 2) {
        $errors['firstName'] = "First name must be at least 2 characters";
    }

    if (empty($lastName)) {
        $errors['lastName'] = "Last name is required";
    }

    if (empty($username)) {
        $errors['username'] = "Username is required";
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $errors['username'] = "Username can only contain letters, numbers, and underscores";
    } elseif (usernameExists($username)) {
        $errors['username'] = "Username already taken";
    }

    if (empty($email)) {
        $errors['email'] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Please enter a valid email address";
    } elseif (emailExists($email)) {
        $errors['email'] = "Email already registered";
    }

    if (empty($password)) {
        $errors['password'] = "Password is required";
    } elseif (strlen($password) < 8) {
        $errors['password'] = "Password must be at least 8 characters";
    } elseif (!preg_match('/[A-Z]/', $password)) {
        $errors['password'] = "Password must contain at least one uppercase letter";
    } elseif (!preg_match('/[a-z]/', $password)) {
        $errors['password'] = "Password must contain at least one lowercase letter";
    } elseif (!preg_match('/[0-9]/', $password)) {
        $errors['password'] = "Password must contain at least one number";
    } elseif (!preg_match('/[^A-Za-z0-9]/', $password)) {
        $errors['password'] = "Password must contain at least one special character";
    }

    if ($password !== $confirmPassword) {
        $errors['confirmPassword'] = "Passwords do not match";
    }

    if (empty($userType)) {
        $errors['userType'] = "Please select a user type";
    }

    if (!$terms) {
        $errors['terms'] = "You must agree to the Terms of Service and Privacy Policy";
    }

    // If no errors, proceed with user creation
    if (empty($errors)) {
        $userData = [
            'username' => $username,
            'email' => $email,
            'firstName' => $firstName,
            'lastName' => $lastName,
            'password' => $password,
            'userType' => $userType,
            'newsletter' => $newsletter
        ];

        $user_id = createUser($userData);

        if ($user_id) {
            // Set session variables
            $_SESSION['user_id'] = $user_id;
            $_SESSION['username'] = $username;
            $_SESSION['email'] = $email;
            $_SESSION['user_type'] = $userType;
            $_SESSION['first_name'] = $firstName;
            
            $success = true;
        } else {
            $errors['database'] = "Error creating account. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - EduGenie</title>
    <link rel="stylesheet" href="auth.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        .error-message {
            color: #ff3860;
            font-size: 12px;
            margin-top: 5px;
            display: none;
        }
        .error-message.show {
            display: block;
        }
        .input-error {
            border-color: #ff3860 !important;
        }
        .success-message {
            background: #23d160;
            color: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
    </style>
</head>
<body class="auth-page">
    <!-- Background Animation -->
    <div class="auth-bg"></div>
    <div class="floating-shapes">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
        <div class="shape shape-3"></div>
        <div class="shape shape-4"></div>
    </div>

    <div class="auth-container">
        <!-- Left Panel -->
        <div class="auth-left-panel">
            <div class="auth-brand">
                <div class="logo">
                    <i class="fas fa-brain"></i>
                    <h1>Edu<span>Genie</span></h1>
                </div>
                <p class="tagline">AI-Powered Learning Assistant</p>
            </div>

            <div class="benefits-list">
                <h3>Why Join Us?</h3>
                <ul>
                    <li>
                        <i class="fas fa-check-circle"></i>
                        <span>Unlimited document analysis</span>
                    </li>
                    <li>
                        <i class="fas fa-check-circle"></i>
                        <span>AI-powered topic extraction</span>
                    </li>
                    <li>
                        <i class="fas fa-check-circle"></i>
                        <span>Personalized study recommendations</span>
                    </li>
                    <li>
                        <i class="fas fa-check-circle"></i>
                        <span>Progress tracking & analytics</span>
                    </li>
                    <li>
                        <i class="fas fa-check-circle"></i>
                        <span>Priority customer support</span>
                    </li>
                </ul>
            </div>

            <div class="stats-grid">
                <div class="stat">
                    <div class="stat-number">10,000+</div>
                    <div class="stat-label">Students</div>
                </div>
                <div class="stat">
                    <div class="stat-number">50,000+</div>
                    <div class="stat-label">Documents Analyzed</div>
                </div>
                <div class="stat">
                    <div class="stat-number">98%</div>
                    <div class="stat-label">Satisfaction Rate</div>
                </div>
            </div>
        </div>

        <!-- Right Panel - Signup Form -->
        <div class="auth-right-panel">
            <div class="auth-header">
                <h2>Create Account</h2>
                <p>Join thousands of students learning smarter</p>

                <div class="auth-tabs">
                    <a href="login.php" class="auth-tab">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </a>
                    <a href="signup.php" class="auth-tab active">
                        <i class="fas fa-user-plus"></i> Sign Up
                    </a>
                </div>
            </div>

            <?php if ($success): ?>
                <div class="auth-success" id="signupSuccess" style="display: block;">
                    <div class="success-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <h3>Account Created Successfully!</h3>
                    <p>Welcome <?php echo htmlspecialchars($firstName); ?>! Redirecting to dashboard...</p>
                    <div class="success-loader"></div>
                </div>
                <script>
                    setTimeout(function() {
                        window.location.href = "dashboard.php";
                    }, 2000);
                </script>
            <?php else: ?>
                <?php if (isset($errors['database'])): ?>
                    <div class="error-message" style="display: block; background: #ff3860; color: white; padding: 10px; border-radius: 5px; margin-bottom: 15px;">
                        <?php echo htmlspecialchars($errors['database']); ?>
                    </div>
                <?php endif; ?>

                <form id="signupForm" class="auth-form" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="firstName">
                                <i class="fas fa-user"></i> First Name
                            </label>
                            <input type="text" id="firstName" name="firstName" placeholder="John" value="<?php echo htmlspecialchars($firstName); ?>" required 
                                class="<?php echo isset($errors['firstName']) ? 'input-error' : ''; ?>">
                            <div class="error-message" id="firstNameError">
                                <?php echo isset($errors['firstName']) ? htmlspecialchars($errors['firstName']) : ''; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="lastName">
                                <i class="fas fa-user"></i> Last Name
                            </label>
                            <input type="text" id="lastName" name="lastName" placeholder="Doe" value="<?php echo htmlspecialchars($lastName); ?>" required 
                                class="<?php echo isset($errors['lastName']) ? 'input-error' : ''; ?>">
                            <div class="error-message" id="lastNameError">
                                <?php echo isset($errors['lastName']) ? htmlspecialchars($errors['lastName']) : ''; ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="username">
                            <i class="fas fa-at"></i> Username
                        </label>
                        <input type="text" id="username" name="username" placeholder="Choose a username" value="<?php echo htmlspecialchars($username); ?>" required 
                            class="<?php echo isset($errors['username']) ? 'input-error' : ''; ?>">
                        <div class="error-message" id="usernameError">
                            <?php echo isset($errors['username']) ? htmlspecialchars($errors['username']) : ''; ?>
                        </div>
                        <div class="input-hint">Only letters, numbers, and underscores</div>
                    </div>

                    <div class="form-group">
                        <label for="email">
                            <i class="fas fa-envelope"></i> Email Address
                        </label>
                        <input type="email" id="email" name="email" placeholder="student@example.com" value="<?php echo htmlspecialchars($email); ?>" required 
                            class="<?php echo isset($errors['email']) ? 'input-error' : ''; ?>">
                        <div class="error-message" id="emailError">
                            <?php echo isset($errors['email']) ? htmlspecialchars($errors['email']) : ''; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="password">
                            <i class="fas fa-lock"></i> Password
                        </label>
                        <div class="password-input">
                            <input type="password" id="password" name="password" placeholder="Create a strong password" required 
                                class="<?php echo isset($errors['password']) ? 'input-error' : ''; ?>">
                            <button type="button" class="toggle-password" id="togglePassword">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="error-message" id="passwordError">
                            <?php echo isset($errors['password']) ? htmlspecialchars($errors['password']) : ''; ?>
                        </div>

                        <div class="password-strength">
                            <div class="strength-bar">
                                <div class="strength-fill" id="strengthFill"></div>
                            </div>
                            <div class="strength-text" id="strengthText">Password strength: None</div>
                        </div>

                        <div class="password-rules">
                            <p>Password must contain:</p>
                            <ul>
                                <li id="ruleLength"><i class="fas fa-times"></i> At least 8 characters</li>
                                <li id="ruleUppercase"><i class="fas fa-times"></i> One uppercase letter</li>
                                <li id="ruleLowercase"><i class="fas fa-times"></i> One lowercase letter</li>
                                <li id="ruleNumber"><i class="fas fa-times"></i> One number</li>
                                <li id="ruleSpecial"><i class="fas fa-times"></i> One special character</li>
                            </ul>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="confirmPassword">
                            <i class="fas fa-lock"></i> Confirm Password
                        </label>
                        <div class="password-input">
                            <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm your password" required 
                                class="<?php echo isset($errors['confirmPassword']) ? 'input-error' : ''; ?>">
                            <button type="button" class="toggle-password" id="toggleConfirmPassword">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="error-message" id="confirmPasswordError">
                            <?php echo isset($errors['confirmPassword']) ? htmlspecialchars($errors['confirmPassword']) : ''; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>
                            <i class="fas fa-graduation-cap"></i> I am a...
                        </label>
                        <div class="user-type-selector">
                            <label class="user-type-option">
                                <input type="radio" name="userType" value="student" <?php echo ($userType == 'student' || $userType == '') ? 'checked' : ''; ?>>
                                <div class="option-content">
                                    <i class="fas fa-user-graduate"></i>
                                    <span>Student</span>
                                </div>
                            </label>
                            <label class="user-type-option">
                                <input type="radio" name="userType" value="teacher" <?php echo $userType == 'teacher' ? 'checked' : ''; ?>>
                                <div class="option-content">
                                    <i class="fas fa-chalkboard-teacher"></i>
                                    <span>Teacher</span>
                                </div>
                            </label>
                            <label class="user-type-option">
                                <input type="radio" name="userType" value="researcher" <?php echo $userType == 'researcher' ? 'checked' : ''; ?>>
                                <div class="option-content">
                                    <i class="fas fa-flask"></i>
                                    <span>Researcher</span>
                                </div>
                            </label>
                        </div>
                        <?php if (isset($errors['userType'])): ?>
                            <div class="error-message" style="display: block;">
                                <?php echo htmlspecialchars($errors['userType']); ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-options">
                        <label class="checkbox">
                            <input type="checkbox" id="terms" name="terms" required <?php echo isset($_POST['terms']) ? 'checked' : ''; ?>>
                            <span class="checkmark"></span>
                            I agree to the <a href="terms.php" class="link">Terms of Service</a> and <a href="privacy.php" class="link">Privacy Policy</a>
                        </label>
                        <?php if (isset($errors['terms'])): ?>
                            <div class="error-message" style="display: block; margin-top: 5px;">
                                <?php echo htmlspecialchars($errors['terms']); ?>
                            </div>
                        <?php endif; ?>

                        <label class="checkbox">
                            <input type="checkbox" id="newsletter" name="newsletter" <?php echo ($newsletter || !isset($_POST['newsletter'])) ? 'checked' : ''; ?>>
                            <span class="checkmark"></span>
                            Subscribe to newsletter & updates
                        </label>
                    </div>

                    <button type="submit" class="auth-submit-btn" id="signupSubmit">
                        <span class="btn-text">Create Account</span>
                        <div class="btn-loader">
                            <div class="spinner"></div>
                        </div>
                        <i class="fas fa-rocket btn-icon"></i>
                    </button>

                    <div class="auth-footer">
                        <p>Already have an account? <a href="login.php">Sign in here</a></p>
                        <p class="terms">
                            By creating an account, you agree to our
                            <a href="terms.php">Terms of Service</a> and
                            <a href="privacy.php">Privacy Policy</a>
                        </p>
                    </div>
                </form>
            <?php endif; ?>
        </div>

        <!-- Back to Home -->
        <a href="index.php" class="back-home">
            <i class="fas fa-arrow-left"></i> Back to Home
        </a>
    </div>

    <script>
        // Toggle password visibility
        document.getElementById('togglePassword').addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            const icon = this.querySelector('i');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });

        document.getElementById('toggleConfirmPassword').addEventListener('click', function() {
            const confirmPasswordInput = document.getElementById('confirmPassword');
            const icon = this.querySelector('i');
            if (confirmPasswordInput.type === 'password') {
                confirmPasswordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                confirmPasswordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });

        // Password strength checker
        document.getElementById('password').addEventListener('input', function() {
            const password = this.value;
            const strengthBar = document.getElementById('strengthFill');
            const strengthText = document.getElementById('strengthText');
            
            let strength = 0;
            const rules = {
                length: password.length >= 8,
                uppercase: /[A-Z]/.test(password),
                lowercase: /[a-z]/.test(password),
                number: /[0-9]/.test(password),
                special: /[^A-Za-z0-9]/.test(password)
            };
            
            // Update rule indicators
            Object.keys(rules).forEach(rule => {
                const ruleElement = document.getElementById('rule' + rule.charAt(0).toUpperCase() + rule.slice(1));
                const icon = ruleElement.querySelector('i');
                if (rules[rule]) {
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-check');
                    icon.style.color = '#23d160';
                    strength++;
                } else {
                    icon.classList.remove('fa-check');
                    icon.classList.add('fa-times');
                    icon.style.color = '#ff3860';
                }
            });
            
            // Update strength bar
            const percentage = (strength / 5) * 100;
            strengthBar.style.width = percentage + '%';
            
            // Update strength text and color
            if (strength === 0) {
                strengthBar.style.backgroundColor = '#ff3860';
                strengthText.textContent = 'Password strength: None';
                strengthText.style.color = '#ff3860';
            } else if (strength <= 2) {
                strengthBar.style.backgroundColor = '#ff7b00';
                strengthText.textContent = 'Password strength: Weak';
                strengthText.style.color = '#ff7b00';
            } else if (strength <= 3) {
                strengthBar.style.backgroundColor = '#ffdd00';
                strengthText.textContent = 'Password strength: Fair';
                strengthText.style.color = '#ffdd00';
            } else if (strength <= 4) {
                strengthBar.style.backgroundColor = '#23d160';
                strengthText.textContent = 'Password strength: Good';
                strengthText.style.color = '#23d160';
            } else {
                strengthBar.style.backgroundColor = '#00d1b2';
                strengthText.textContent = 'Password strength: Strong';
                strengthText.style.color = '#00d1b2';
            }
        });

        // Form submission
        document.getElementById('signupForm')?.addEventListener('submit', function(e) {
            const submitBtn = document.getElementById('signupSubmit');
            const btnText = submitBtn.querySelector('.btn-text');
            const btnLoader = submitBtn.querySelector('.btn-loader');
            
            // Show loading state
            submitBtn.disabled = true;
            btnText.textContent = 'Creating Account...';
            btnLoader.style.display = 'block';
        });

        // Show error messages on page load
        document.addEventListener('DOMContentLoaded', function() {
            const errorElements = document.querySelectorAll('.error-message');
            errorElements.forEach(element => {
                if (element.textContent.trim() !== '') {
                    element.style.display = 'block';
                    const input = element.parentElement.querySelector('input');
                    if (input) {
                        input.classList.add('input-error');
                    }
                }
            });
        });
    </script>
</body>
</html>
<link rel="stylesheet" href="singupandlogingcss.css">

<body>
    </body>